Docker support was dropped in kind 0.3.0 in favour of containerd.

This package is based on kind 0.2.1, but then the code evolved in order to keep up with kind evolution (e.g. introduction of port mappings) and to adapt
to the kinder specific needs/code organization.
