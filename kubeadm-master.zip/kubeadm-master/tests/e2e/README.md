### kubeadm e2e tests

This folder contains kubeadm e2e tests that run as periodic jobs.

The definitions for these jobs can be found in the test-infra repository
[here](https://github.com/kubernetes/test-infra/tree/master/config/jobs/kubernetes/sig-cluster-lifecycle).

Test results can be monitored in this [testgrid dashboard](https://k8s-testgrid.appspot.com/sig-cluster-lifecycle-all).
