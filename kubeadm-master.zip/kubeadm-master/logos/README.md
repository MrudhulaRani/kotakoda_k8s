## kubeadm Logos

*Note: GitHub Flavored Markdown used in the Readme doesn't support background colors. The white logos below are displayed on the light grey of tables.*


<table>
    <tr>
    	<th colspan="7"></th>
    </tr>
    <tr>
        <th></th>
        <th colspan="3">PNG</th>
        <th colspan="3">SVG</th>
    </tr>
    <tr>
        <th></th>
        <th>horizontal</th>
        <th>stacked</th>
        <th>icon</th>
        <th>horizontal</th>
        <th>stacked</th>
        <th>icon</th>
    </tr>
    <tr>
        <th>color</th>
        <td><img src="/logos/horizontal/color/kubeadm-horizontal-color.png" width="200"></td>
        <td><img src="/logos/stacked/color/kubeadm-stacked-color.png" width="95"></td>
        <td><img src="/logos/icon/color/kubeadm-icon-color.png" width="75"></td>
        <td><img src="/logos/horizontal/color/kubeadm-horizontal-color.svg" width="200"></td>
        <td><img src="/logos/stacked/color/kubeadm-stacked-color.svg" width="95"></td>
        <td><img src="/logos/icon/color/kubeadm-icon-color.svg" width="75"></td>
    </tr>
    <tr>
        <th>black</th>
        <td><img src="/logos/horizontal/black/kubeadm-horizontal-black.png" width="200"></td>
        <td><img src="/logos/stacked/black/kubeadm-stacked-black.png" width="95"></td>
        <td><img src="/logos/icon/black/kubeadm-icon-black.png" width="75"></td>
        <td><img src="/logos/horizontal/black/kubeadm-horizontal-black.svg" width="200"></td>
        <td><img src="/logos/stacked/black/kubeadm-stacked-black.svg" width="95"></td>
        <td><img src="/logos/icon/black/kubeadm-icon-black.svg" width="75"></td>
    </tr>
    <tr>
        <th>white</th>
        <td><img src="/logos/horizontal/white/kubeadm-horizontal-white.png" width="200"></td>
        <td><img src="/logos/stacked/white/kubeadm-stacked-white.png" width="95"></td>
        <td><img src="/logos/icon/white/kubeadm-icon-white.png" width="75"></td>
        <td><img src="/logos/horizontal/white/kubeadm-horizontal-white.svg" width="200"></td>
        <td><img src="/logos/stacked/white/kubeadm-stacked-white.svg" width="95"></td>
        <td><img src="/logos/icon/white/kubeadm-icon-white.svg" width="75"></td>
    </tr>
</table>
